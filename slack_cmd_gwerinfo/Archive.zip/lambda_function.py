from __future__ import print_function
import os

from datetime import datetime
import urllib
from models import Switch, CustomerQuery, NoParamQuery
from commands import AssignedCommand, SubmittedCommand, AppliedCommand, AllPublicCommand

EXPECTED = os.environ['expected'].split(',')  # String expected to be on the page, stored in the expected environment variable, e.g. Amazon
AUTHORIZED_USERS = os.environ.get('AUTHORIZED_USERS').split(',')

def validate(event):
    auth = (event.get('token') in EXPECTED and event.get('team_domain') == 'gigwalk' and event.get('user_name') in AUTHORIZED_USERS)
    if not auth:
        raise Exception('Validation failed')

    param = None
    command = None
    try:
        print(event.get('command'), event.get('text'))
        # url decoding, not really needed with proper cleaning upfront in API gateway
        param = urllib.unquote(event.get('text')).lower() if event.get('text') else None
        command = urllib.unquote(event.get('command'))[1:]
        # TODO params and command validation
    except Exception as e:
        print(e)
        raise ValueError('Something goes wrong unexpected, note down your command/parameter and contact Derek')
    return command, param


def lambda_handler(event, context):
    try:
        print(event)
        command, param = validate(event)
        light = None
        commandObj = None
        response = "Something wrong with your query.  How may I help you?"

        switch = Switch()

        if command == 'assigned': 
            light = CustomerQuery(param)
            commandObj = AssignedCommand(light)  
        elif command == 'applied':
            light = CustomerQuery(param)
            commandObj = AppliedCommand(light)
        elif command == 'submitted':
            light = CustomerQuery(param)
            commandObj = SubmittedCommand(light)
        elif command == 'allpublic':
            light = NoParamQuery()
            commandObj = AllPublicCommand(light)
        elif command == 'worker':
            light = SimpleQuery(param)
            commandObj = WorkerCommand(light)
        if light and commandObj:
            response = switch.execute(commandObj)
        return response
    except Exception as e:
        print(e)
        return str(e)
        #{"text": "Something goes wrong"}
    finally:
        print('Check complete at {}'.format(str(datetime.now())))
